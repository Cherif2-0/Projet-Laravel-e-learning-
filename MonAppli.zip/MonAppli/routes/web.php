<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|Route::get('/', function () {
    return view('welcome');
});
*/


Route::get('/', function () {
   return view('home');
});
Route::get('/login', function () {
    return view('login');
 });
 Route::get('/forum', function () {
   return view('forum');
});
 Route::get('/bonjour',"MainController@bonjour");

 Route::get('/inscription', function () {
   return view('inscription');
});
Route::post('/inscription', function () {
   $student = new App\Student ;
   $student->email = request('email');
   $student->pseudo = request('pseudo');
   $student->mdp = request('mdp');
   $student->save();

   echo ' <center><head>
   <meta charset="UTF-8">
   
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
   
   <!-- Favicons -->
<link rel="icon" href="{{asset(\'img/icon.png\')}}">
<link rel="stylesheet" href="{{asset(\'css/style.css\')}}">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>inscription</title>
</head>
<body style="width:50%;margin:1cm auto;">
   <div class="jumbotron">
 <h1 class="display-4">Inscription validée !</h1>
 <p class="lead">Bonjour <b>'.request("pseudo").'</b> <br> La plateforme Kay-Coder vous remercie de votre confiance et vous propose
  une formation à distance de qualité et vous pouvez les information suivantes pour vous connecter <br>
  <b> Email : '.request("email").'</b> <br><b> Mot de passe : '.request("mdp").'</b> <br> </p>
 <p class="lead">
   <a class="btn btn-primary btn-lg" href="home.blade.php" role="button">Visitez la plateforme ! </a>
 </p>
</div>
</body>
</center>';
});
Route::post('/forum', function () {
   $forum = new App\Forum ;
   $forum->pseudo = request('pseudo');
   $forum->msg = request('msg');
   $forum->save();
   return view('/forum');
});

Route::get('/forum',function(){
   $forum=App\Forum::all();
   return view('forum',[
      'forum'=>$forum,
   ]);
});
/*
Route::get('/inscription',"StudentController@index");
Route::get('/inscription/edit/{id}',"StudentController@edit");
Route::get('/inscription/show/{id}',"StudentController@show");
Route::get('/inscription/create',"StudentController@create");
Route::get('/inscription/store',"StudentController@store");
Route::get('/inscription/update/{id}',"StudentController@update");*/


 Route::get('/html', function () {
    return view('html');
 });