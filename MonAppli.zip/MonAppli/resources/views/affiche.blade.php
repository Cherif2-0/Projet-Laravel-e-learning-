<div class="aff">
            @foreach($afficher as $forum)
                <div class="table">
                    <table style="width:80%;">
                        <tr><th>{{ $forum->pseudo }}</th></tr>
                        <tr>
                            <td>{{ $forum->msg }}</td>
                        </tr>
                    </table>
                </div>
            @endforeach
        </div>