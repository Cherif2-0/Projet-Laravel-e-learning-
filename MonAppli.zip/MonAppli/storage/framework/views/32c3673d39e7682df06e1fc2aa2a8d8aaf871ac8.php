
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
    <!-- Favicons -->
<link rel="icon" href="<?php echo e(asset('img/icon.png')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>inscription</title>
</head>
<body id="form">
<header>
  <div class="collapse bg-dark" id="navbarHeader">
    <div class="container">
      <div class="row">
        <div class="col-sm-8 col-md-7 py-4">
          <h4 class="text-white">About</h4>
          <p class="text-muted">Add some information about the album below, the author, or any other background context. Make it a few sentences long so folks can pick up some informative tidbits. Then, link them off to some social networking sites or contact information.</p>
        </div>
        <div class="col-sm-4 offset-md-1 py-4">
          <h4 class="text-white">Contact</h4>
          <ul class="list-unstyled">
            <li><a href="#" class="text-white">Follow on Twitter</a></li>
            <li><a href="#" class="text-white">Like on Facebook</a></li>
            <li><a href="#" class="text-white">Email me</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <div class="navbar navbar-dark bg-dark shadow-sm">
    <div class="container" style="margin:0px;padding:0px;">
      <a href="#" class="navbar-brand d-flex align-items-center">
    <!--  <img class="img" width=50 height=50 src="<?php echo e(asset('img/icon.png')); ?>" alt="">-->
        <strong>Acceuil</strong>
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarHeader" aria-controls="navbarHeader" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    </div>
  </div>
</header>
    <div class="container">
        <div class="row">
            <div class="col-lg-10">
            <div class="form" id="register">
            <form action="/forum" method="post">
            <?php echo e(csrf_field()); ?>

            <center><h2> Forum de partage </h2>
            </center>
                <label for="">Pseudo</label> <br>
                <input id="pseudo" type="text" name="pseudo"><br> <br>
                <textarea name="msg" placeholder="Votre message..." id="" cols="72" rows="8"></textarea>
                
                <input class="btn btn-warning" style="width:200px;" type="submit" value="Envoyer">
            </form>
            </div>
            </div>
            <div class="col-lg-2" id="image__gauche">
            <img class="img" width=300 height=300 src="<?php echo e(asset('img/icon.png')); ?>" alt="">
            </div>
        </div>
        <div class="row">
            <div class="col-lg-10">
                <h2>Les messages </h2>
            <?php $__currentLoopData = $forum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $forum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="msg">
                    <table>
                        <tr><th ><?php echo e($forum->pseudo); ?></th></tr>
                        <tr>
                            <td style="padding:10px;"><?php echo e($forum->msg); ?></td>
                        </tr>
                    </table>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
            <div class="col-lg-2 langages"  >
                <ul>
                    <li><a href="#">HTML 5</a></li>
                    <li><a href="#">CSS 3</a></li>
                    <li><a href="#">JS</a></li>
                    <li><a href="#">PHP</a></li>
                    <li><a href="#">JAVA</a></li>
                    <li><a href="#">SQL</a></li>
                    <li><a href="#">Laravel</a></li>
                    <li><a href="#">React</a></li>
                    <li><a href="#">bootstrap</a></li>
                </ul>
            </div>
        </div>
    </div>
</body>
</html>