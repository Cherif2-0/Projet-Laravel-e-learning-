<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.79.0">
    <title>Kay coder</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.0/examples/album/">

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
    <!-- Favicons -->
<link rel="icon" href="<?php echo e(asset('img/icon.png')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
<meta name="theme-color" content="#7952b3">
  </head>
  <body>
    
<header>
  <div class="collapse bg-dark" id="navbarHeader">
    <div class="container">
      <div class="row">
        <div class="col-sm-8 col-md-7 py-4">
          <h4 class="text-white">About</h4>
          <p class="text-muted">Add some information about the album below, the author, or any other background context. Make it a few sentences long so folks can pick up some informative tidbits. Then, link them off to some social networking sites or contact information.</p>
        </div>
        <div class="col-sm-4 offset-md-1 py-4">
          <h4 class="text-white">Contact</h4>
          <ul class="list-unstyled">
            <li><a href="#" class="text-white">Follow on Twitter</a></li>
            <li><a href="#" class="text-white">Like on Facebook</a></li>
            <li><a href="#" class="text-white">Email me</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <div class="navbar navbar-dark bg-dark shadow-sm">
    <div class="container" style="margin:0px;padding:0px;">
      <a href="#" class="navbar-brand d-flex align-items-center">
    <!--  <img class="img" width=50 height=50 src="<?php echo e(asset('img/icon.png')); ?>" alt="">-->
        <strong>Acceuil</strong>
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarHeader" aria-controls="navbarHeader" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    </div>
  </div>
</header>

<main>

  <section class="py-5 text-center container">
    <div class="row py-lg-0">
      <div class="col-lg-6 col-md-8 mx-auto">
        <h1 class="fw-light">Kay Coder</h1> <img class="img" width=200 height=200 src="<?php echo e(asset('img/icon.png')); ?>" alt=""><br>
          <a href="<?php echo e(url('/inscription')); ?>" class="btn btn-warning my-2">inscription</a>
          <a href="<?php echo e(url('/login')); ?>" class="btn btn-secondary my-2">connection</a>
          <a href="<?php echo e(url('/forum')); ?>" class="btn btn-danger my-2">Forum</a>
        </p>
      </div>
    </div>
  </section>

  <div class="album py-5  g">
    <div class="container ">

      <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
        <div class="col">
          <div class="card shadow-sm">
          <img class="img" width=150 height=150 src="<?php echo e(asset('img/html.png')); ?>" alt="">
            <div class="card-body">
              <p class="card-text">L'HTML est un langage informatique utilisé sur l'internet. Ce langage est utilisé
                 pour créer des pages web. L'acronyme signifie HyperText Markup Language, en français "langage de balisage d'hypertexte". </p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary"><a href="<?php echo e(url('/html')); ?>"> Apprendre</a></button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">s'exercer </button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
          <img class="img" width=150 height=150 src="<?php echo e(asset('img/css.png')); ?>" alt="">
            <div class="card-body">
              <p class="card-text">CSS est l'acronyme de « Cascading Style Sheets » ce qui signifie « feuille de style en cascade ».
                 Le CSS correspond à un langage informatique permettant de mettre en forme des pages web (HTML ou XML). </p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">Apprendre</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">s'exercer </button>
                </div>
               
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
          <img class="img" width=150 height=150 src="<?php echo e(asset('img/js.png')); ?>" alt="">

            <div class="card-body">
              <p class="card-text">JavaScript est un langage de programmation de scripts principalement employé dans 
                les pages web interactives et à ce titre est une partie essentielle des applications web. </p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">Apprendre</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">s'exercer </button>
                </div>
               
              </div>
            </div>
          </div>
        </div>
      <br>
        <div class="col">
          <div class="card shadow-sm">
          <img class="img" width=300 height=150 src="<?php echo e(asset('img/php.png')); ?>" alt="">

            <div class="card-body">
              <p class="card-text">PHP: Hypertext Preprocessor, est un langage de programmation libre,
               principalement utilisé pour produire des pages Web dynamiques via un serveur HTTP, mais pouvant également fonctionner comme
               n'importe quel langage interprété de façon locale.</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">Apprendre</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">s'exercer </button>
                </div>
               
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
          <img class="img" width=100 height=150 src="<?php echo e(asset('img/java.png')); ?>" alt="">

            <div class="card-body">
              <p class="card-text">Java est un langage de programmation orienté objet créé par James Gosling et Patrick Naughton,
               employés de Sun Microsystems, avec le soutien de Bill Joy.
               Beaucoup de sites Web ne fonctionnent pas si Java n'est pas installé. Java est rapide, sécurisé et fiable. </p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">Apprendre</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">s'exercer </button>
                </div>
               
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
          <img class="img" width=150 height=150 src="<?php echo e(asset('img/mysql.png')); ?>" alt="">

            <div class="card-body">
              <p class="card-text">MySQL est un système de gestion de bases de données relationnelles. Il est distribué sous
               une double licence GPL et propriétaire MySQL Database Service est un service de base de données entièrement géré 
               pour déployer des applications natives du cloud en utilisant la base de données</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">Apprendre</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">s'exercer </button>
                </div>
               
              </div>
            </div>
          </div>
        </div>

        <div class="col">
          <div class="card shadow-sm">
          <img class="img" width=150 height=150 src="<?php echo e(asset('img/bootstrap.png')); ?>" alt="">

            <div class="card-body">
              <p class="card-text">Bootstrap est une collection d'outils utiles à la création du design de sites et d'applications web.
               C'est un ensemble qui contient des codes HTML et CSS, des formulaires, boutons, outils de navigation et autres éléments interactifs,</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">Apprendre</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">s'exercer </button>
                </div>
               
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
          <img class="img" width=150 height=150 src="<?php echo e(asset('img/jquery.png')); ?>" alt="">

            <div class="card-body">
              <p class="card-text">jQuery est une bibliothèque JavaScript libre et multiplateforme créée pour faciliter
               l'écriture de scripts côté client dans le code HTML des pages web. La devise de jQuery est de faciliter votre manière de coder. La première version est lancée en janvier 2006 </p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">Apprendre</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">s'exercer </button>
                </div>
               
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
          <img class="img" width=250 height=150 src="<?php echo e(asset('img/laravel.png')); ?>" alt="">

            <div class="card-body">
              <p class="card-text">Laravel est un framework web open-source écrit en PHP respectant 
              le principe modèle-vue-contrôleur et entièrement développé en programmation orientée objet.
               Laravel est distribué sous licence MIT, avec ses sources hébergées sur GitHub</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">Apprendre</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">s'exercer </button>
                </div>
               
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

</main>

<footer class="text-muted py-5">
  <div class="container">
    <p class="text-center mb-1">
    <b>copyright2021@cherif2.0 tout droit réservé</b>
    </p>
 </div>
</footer>


    <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

      
  </body>
</html>