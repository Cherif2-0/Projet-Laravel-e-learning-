<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    
    <link rel="canonical" href="https://getbootstrap.com/docs/5.0/examples/album/">

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
    <!-- Favicons -->
<link rel="icon" href="<?php echo e(asset('img/icon.png')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>html</title>
</head>
<body> 
<header>
  <div class="collapse bg-dark" id="navbarHeader">
    <div class="container">
      <div class="row">
        <div class="col-sm-8 col-md-7 py-4">
          <h4 class="text-white">About</h4>
          <p class="text-muted">Add some information about the album below, the author, or any other background context. Make it a few sentences long so folks can pick up some informative tidbits. Then, link them off to some social networking sites or contact information.</p>
        </div>
        <div class="col-sm-4 offset-md-1 py-4">
          <h4 class="text-white">Contact</h4>
          <ul class="list-unstyled">
            <li><a href="#" class="text-white">Follow on Twitter</a></li>
            <li><a href="#" class="text-white">Like on Facebook</a></li>
            <li><a href="#" class="text-white">Email me</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <div class="navbar navbar-dark bg-dark shadow-sm">
    <div class="container" style="margin:0px;padding:0px;">
      <a href="#" class="navbar-brand d-flex align-items-center">
    <!--  <img class="img" width=50 height=50 src="<?php echo e(asset('img/icon.png')); ?>" alt="">-->
        <strong>Acceuil</strong>
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarHeader" aria-controls="navbarHeader" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    </div>
  </div>
</header>
    <div class="container"><h2>Bienvenue en html</h2> <br>
        <div class="row">
            <div class="col-lg-6 text">
                <h3>Aprendre en version text !</h3>
                <p>
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Repellat molestiae 
                    odio ea totam mollitia, iusto ullam beatae tempore voluptas praesentium ducimus 
                    iure tempora in dignissimos delectus consectetur, eos distinctio vel.
                </p>
            </div>
            <div class="col-lg-6 video">
                <h3>Aprrendre en version vidéo !</h3>
                <p>
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Repellat molestiae 
                    odio ea totam mollitia, iusto ullam beatae tempore voluptas praesentium ducimus 
                    iure tempora in dignissimos delectus consectetur, eos distinctio vel.
                </p>
            </div>
        </div>
    </div>
</body>
</html>