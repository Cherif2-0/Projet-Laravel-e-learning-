<div class="aff">
            <?php $__currentLoopData = $forum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $forum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="table">
                    <table style="width:80%;">
                        <tr><th><?php echo e($forum->pseudo); ?></th></tr>
                        <tr>
                            <td><?php echo e($forum->msg); ?></td>
                        </tr>
                    </table>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>