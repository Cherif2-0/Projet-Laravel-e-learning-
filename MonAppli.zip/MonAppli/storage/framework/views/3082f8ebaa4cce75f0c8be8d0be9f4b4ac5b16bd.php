<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
    <!-- Favicons -->
<link rel="icon" href="<?php echo e(asset('img/icon.png')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>inscription</title>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
            <div class="form" id="register">
            <form action="/inscription" method="post">
            <?php echo e(csrf_field()); ?>

            <center><h2> inscription </h2>
            </center>
                <label for="">Nom</label> <br>
                <input type="text" name="pseudo"><br> <br>
                <label for="">prénom</label> <br>
                <input type="text" name="pseudo"><br> <br>
                <label for="">email</label> <br>
                <input type="" name="email"><br> <br>
                <label for="">Mot de passe</label> <br>
                <input type="password" name="mdp"><br> <br>
                
                <input class="inscription" type="submit" value="s'inscrire">
            </form>
        </div>
            </div>
            <div class="col-sm-4" id="image__gauche">
            <img class="img" width=300 height=300 src="<?php echo e(asset('img/icon.png')); ?>" alt="">
                
            </div>
        </div>
        
    </div>
</body>
</html>